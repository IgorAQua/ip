#!/usr/bin/env bash

# Sourced by HiveOS. Always leave numeric `khs` and valid JSON (or null) in `stats`.
khs=0
stats=null

_pearlski_stats_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$_pearlski_stats_dir/h-manifest.conf"

_pearlski_log=${PEARLSKI_LOG_FILE:-${CUSTOM_LOG_BASENAME}.log}
_pearlski_start="$_pearlski_stats_dir/miner_start_time"
_pearlski_snapshot="$_pearlski_stats_dir/miner_latest_stats"
_pearlski_snapshot_mode="$_pearlski_stats_dir/stats_snapshot_v1"
_pearlski_generation="$_pearlski_stats_dir/capture.generation"

_pearlski_rate_to_khs() {
    local value=$1 prefix=${2:-}
    awk -v value="$value" -v prefix="$prefix" 'BEGIN {
        prefix = tolower(prefix)
        multiplier = 0.001
        if (prefix == "k") multiplier = 1
        else if (prefix == "m") multiplier = 1000
        else if (prefix == "g") multiplier = 1000000
        else if (prefix == "t") multiplier = 1000000000
        else if (prefix == "p") multiplier = 1000000000000
        else if (prefix == "e") multiplier = 1000000000000000
        printf "%.0f", value * multiplier
    }'
}

_pearlski_join() {
    local IFS=,
    printf '%s' "$*"
}

_pearlski_parse_stats() {
    local now mtime line total_value total_prefix accepted rejected total_khs generation
    local rest token gpu value prefix idx temp fan pci bus_hex bus
    local stale_sec smi_timeout
    local uptime=0
    local had_nocasematch=0
    local -a gpu_ids=() rates=() temps=() fans=() buses=()
    local -A temp_by_gpu=() fan_by_gpu=() bus_by_gpu=()

    now=$(date +%s)
    [[ "$now" =~ ^[0-9]+$ ]] || return 0
    stale_sec=${PEARLSKI_STATS_STALE_SEC:-120}
    [[ "$stale_sec" =~ ^[0-9]+$ ]] || stale_sec=120
    if [[ -e "$_pearlski_snapshot_mode" ]]; then
        if [[ -e "$_pearlski_generation" ]]; then
            read -r generation < "$_pearlski_generation" || return 0
            [[ "$generation" =~ ^run-[0-9]+-[0-9]+-[0-9]+-[0-9]+$ ]] || return 0
            _pearlski_snapshot="$_pearlski_stats_dir/miner_latest_stats.$generation"
        fi
        [[ -s "$_pearlski_snapshot" ]] || return 0
        mtime=$(stat -Lc %Y "$_pearlski_snapshot" 2>/dev/null || printf '0')
        [[ "$mtime" =~ ^[0-9]+$ ]] || return 0
        (( now >= mtime && now - mtime <= stale_sec )) || return 0
        line=$(tail -n 1 "$_pearlski_snapshot" 2>/dev/null \
            | sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g; s/\r$//')
    else
        # Compatibility with older h-run.sh versions that only wrote a log.
        [[ -s "$_pearlski_log" ]] || return 0
        mtime=$(stat -Lc %Y "$_pearlski_log" 2>/dev/null || printf '0')
        [[ "$mtime" =~ ^[0-9]+$ ]] || return 0
        (( now >= mtime && now - mtime <= stale_sec )) || return 0
        line=$(tail -n 2000 "$_pearlski_log" 2>/dev/null \
            | sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g; s/\r$//' \
            | awk '{ lower=tolower($0) } lower ~ /gpu\[[0-9]+\]/ && lower ~ /\|[[:space:]]*a:[0-9]+[[:space:]]+r:[0-9]+/ { last=$0 } END { print last }')
    fi
    [[ -n "$line" ]] || return 0

    shopt -q nocasematch && had_nocasematch=1
    shopt -s nocasematch
    if [[ "$line" =~ ([0-9]+([.][0-9]+)?)[[:space:]]*([kmgtpe]?)h/s[[:space:]]*\|[[:space:]]*A:([0-9]+)[[:space:]]+R:([0-9]+) ]]; then
        total_value=${BASH_REMATCH[1]}
        total_prefix=${BASH_REMATCH[3]// /}
        accepted=${BASH_REMATCH[4]}
        rejected=${BASH_REMATCH[5]}
    else
        (( had_nocasematch )) || shopt -u nocasematch
        return 0
    fi

    rest=$line
    while [[ "$rest" =~ GPU\[([0-9]+)\][[:space:]]+([0-9]+([.][0-9]+)?)[[:space:]]*([kmgtpe]?)h/s ]]; do
        token=${BASH_REMATCH[0]}
        gpu=${BASH_REMATCH[1]}
        value=${BASH_REMATCH[2]}
        prefix=${BASH_REMATCH[4]}
        gpu_ids+=("$gpu")
        rates+=("$(_pearlski_rate_to_khs "$value" "$prefix")")
        rest=${rest#*"$token"}
    done
    (( had_nocasematch )) || shopt -u nocasematch
    ((${#gpu_ids[@]} > 0)) || return 0

    smi_timeout=${PEARLSKI_NVIDIA_SMI_TIMEOUT_SEC:-5}
    [[ "$smi_timeout" =~ ^[1-9][0-9]*$ ]] || smi_timeout=5
    while IFS=, read -r idx temp fan pci; do
        idx=${idx//[[:space:]]/}
        temp=${temp//[[:space:]]/}
        fan=${fan//[[:space:]]/}
        pci=${pci//[[:space:]]/}
        [[ "$idx" =~ ^[0-9]+$ ]] || continue
        [[ "$temp" =~ ^[0-9]+$ ]] || temp=0
        [[ "$fan" =~ ^[0-9]+$ ]] || fan=0
        bus_hex=${pci#*:}
        bus_hex=${bus_hex%%:*}
        if [[ "$bus_hex" =~ ^[0-9A-Fa-f]+$ ]]; then
            bus=$((16#$bus_hex))
        else
            bus=0
        fi
        temp_by_gpu[$idx]=$temp
        fan_by_gpu[$idx]=$fan
        bus_by_gpu[$idx]=$bus
    done < <(
        if command -v timeout >/dev/null 2>&1 && command -v nvidia-smi >/dev/null 2>&1; then
            timeout -k 1s "${smi_timeout}s" \
                nvidia-smi \
                --query-gpu=index,temperature.gpu,fan.speed,pci.bus_id \
                --format=csv,noheader,nounits 2>/dev/null
        fi
    )

    for gpu in "${gpu_ids[@]}"; do
        temps+=("${temp_by_gpu[$gpu]:-0}")
        fans+=("${fan_by_gpu[$gpu]:-0}")
        buses+=("${bus_by_gpu[$gpu]:-0}")
    done

    if [[ -r "$_pearlski_start" ]]; then
        read -r mtime < "$_pearlski_start"
        [[ "$mtime" =~ ^[0-9]+$ ]] && (( now >= mtime )) && uptime=$((now - mtime))
    fi

    total_khs=$(_pearlski_rate_to_khs "$total_value" "$total_prefix")
    # Hive reads these variables after sourcing this script.
    # shellcheck disable=SC2034
    khs=$total_khs
    # shellcheck disable=SC2034
    printf -v stats '{"hs":[%s],"hs_units":"khs","temp":[%s],"fan":[%s],"uptime":%s,"ver":"1.5.6","ar":[%s,%s],"algo":"pearlhash","bus_numbers":[%s]}' \
        "$(_pearlski_join "${rates[@]}")" \
        "$(_pearlski_join "${temps[@]}")" \
        "$(_pearlski_join "${fans[@]}")" \
        "$uptime" "$accepted" "$rejected" \
        "$(_pearlski_join "${buses[@]}")"
}

_pearlski_parse_stats
unset -f _pearlski_rate_to_khs _pearlski_join _pearlski_parse_stats
unset _pearlski_stats_dir _pearlski_log _pearlski_start
unset _pearlski_snapshot _pearlski_snapshot_mode _pearlski_generation
