#!/usr/bin/env bash

set -u

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$SCRIPT_DIR/h-manifest.conf"

CONFIG_FILE=${CUSTOM_CONFIG_FILENAME:-$SCRIPT_DIR/pearlski.conf}
if [[ ! -r "$CONFIG_FILE" ]]; then
    echo "Pearlski run error: missing config $CONFIG_FILE" >&2
    exit 1
fi
# shellcheck source=/dev/null
source "$CONFIG_FILE"

if ! declare -p PEARLSKI_ARGS 2>/dev/null | grep -q '^declare -a '; then
    echo "Pearlski run error: miner arguments are not an array" >&2
    exit 1
fi
if ((${#PEARLSKI_ARGS[@]} == 0)); then
    echo "Pearlski run error: no miner arguments configured" >&2
    exit 1
fi

BIN="$SCRIPT_DIR/pearlski-miner"
LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
STATE_FILE="$SCRIPT_DIR/miner.state"
LOCK_FILE="$SCRIPT_DIR/miner.lock"
START_FILE="$SCRIPT_DIR/miner_start_time"
STATS_LINE_FILE="$SCRIPT_DIR/miner_latest_stats"
STATS_MODE_FILE="$SCRIPT_DIR/stats_snapshot_v1"
GENERATION_FILE="$SCRIPT_DIR/capture.generation"

# Removed after upgrading from wrappers that used three separate state files.
LEGACY_PID_FILE="$SCRIPT_DIR/miner.pid"
LEGACY_PGID_FILE="$SCRIPT_DIR/miner.pgid"
LEGACY_PROC_START_FILE="$SCRIPT_DIR/miner_proc_start"

if [[ ! -x "$BIN" ]]; then
    echo "Pearlski run error: binary is missing or not executable: $BIN" >&2
    exit 1
fi
if ! command -v setsid >/dev/null 2>&1; then
    echo "Pearlski run error: setsid is required for supervised GPU cleanup" >&2
    exit 1
fi
if ! command -v flock >/dev/null 2>&1; then
    echo "Pearlski run error: flock is required for serialized lifecycle control" >&2
    exit 1
fi

mkdir -p "$(dirname -- "$LOG_FILE")" || exit 1

export CUDA_DEVICE_ORDER=PCI_BUS_ID
export PEARLSKI_LOG_LEVEL=${PEARLSKI_LOG_LEVEL:-Information}
export PEARLSKI_MINE_STATS_INTERVAL_SEC=${PEARLSKI_MINE_STATS_INTERVAL_SEC:-10}
unset PEARLSKI_LOG_JSON PEARLSKI_SUPERVISED_PROCESS PEARLSKI_SUPERVISED_TELEMETRY
if [[ ${PEARLSKI_USE_TLS:-0} == 1 ]]; then
    export PEARLSKI_POOL_TLS=1
else
    unset PEARLSKI_POOL_TLS
fi

miner_pid=
miner_pgid=
miner_proc_start=
miner_exe_identity=
capture_pid=
state_tmp=
start_tmp=
generation_tmp=
log_link_tmp=
run_token=
run_log_file=
run_stats_file=
cleanup_done=0
lock_held=0
state_published=0

_pearlski_group_has_live_members() {
    local pgid=$1
    ps -eo pgid=,stat= 2>/dev/null \
        | awk -v wanted="$pgid" '$1 == wanted && $2 !~ /^Z/ { found=1 } END { exit !found }'
}

_pearlski_proc_exe_identity() {
    stat -Lc '%d:%i' "/proc/$1/exe" 2>/dev/null
}

_pearlski_group_has_identity() {
    local wanted_pgid=$1 wanted_identity=$2
    local member member_pgid member_stat identity

    while read -r member member_pgid member_stat; do
        [[ "$member_pgid" == "$wanted_pgid" && "$member_stat" != Z* ]] || continue
        identity=$(_pearlski_proc_exe_identity "$member")
        [[ "$identity" == "$wanted_identity" ]] && return 0
    done < <(ps -eo pid=,pgid=,stat= 2>/dev/null)
    return 1
}

_pearlski_group_has_legacy_binary() {
    local wanted_pgid=$1
    local member member_pgid member_stat exe

    while read -r member member_pgid member_stat; do
        [[ "$member_pgid" == "$wanted_pgid" && "$member_stat" != Z* ]] || continue
        exe=$(readlink -f "/proc/$member/exe" 2>/dev/null || true)
        exe=${exe%" (deleted)"}
        [[ "$exe" == "$BIN" ]] && return 0
    done < <(ps -eo pid=,pgid=,stat= 2>/dev/null)
    return 1
}

_pearlski_saved_state_is_live() {
    local version pid pgid saved_start saved_identity current_start

    if [[ -r "$STATE_FILE" ]] \
        && read -r version pid pgid saved_start saved_identity < "$STATE_FILE" \
        && [[ "$version" == 1 ]] \
        && [[ "$pid" =~ ^[0-9]+$ ]] \
        && [[ "$pgid" =~ ^[0-9]+$ && "$pgid" == "$pid" ]] \
        && [[ "$saved_start" =~ ^[0-9]+$ ]] \
        && [[ "$saved_identity" =~ ^[0-9]+:[0-9]+$ ]]; then
        current_start=$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null || true)
        [[ "$current_start" == "$saved_start" ]] && return 0
        _pearlski_group_has_identity "$pgid" "$saved_identity" && return 0
        return 1
    fi

    [[ -r "$LEGACY_PID_FILE" ]] || return 1
    read -r pid < "$LEGACY_PID_FILE" || return 1
    read -r pgid < "$LEGACY_PGID_FILE" 2>/dev/null || pgid=
    read -r saved_start < "$LEGACY_PROC_START_FILE" 2>/dev/null || saved_start=
    [[ "$pid" =~ ^[0-9]+$ ]] || return 1
    [[ "$pgid" =~ ^[0-9]+$ && "$pgid" == "$pid" ]] || return 1
    [[ "$saved_start" =~ ^[0-9]+$ ]] || return 1

    current_start=$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null || true)
    [[ "$current_start" == "$saved_start" ]] && return 0
    _pearlski_group_has_legacy_binary "$pgid"
}

_pearlski_remove_all_state() {
    rm -f -- \
        "$STATE_FILE" "$START_FILE" "$STATS_LINE_FILE" "$GENERATION_FILE" \
        "$LEGACY_PID_FILE" "$LEGACY_PGID_FILE" "$LEGACY_PROC_START_FILE"
}

_pearlski_remove_owned_generation() {
    local saved_token

    [[ -n "${run_token:-}" && -r "$GENERATION_FILE" ]] || return 0
    read -r saved_token < "$GENERATION_FILE" || return 0
    [[ "$saved_token" == "$run_token" ]] || return 0
    rm -f -- "$GENERATION_FILE"
}

_pearlski_remove_owned_state() {
    local version saved_pid saved_pgid saved_start saved_identity

    if [[ -r "$STATE_FILE" ]]; then
        if ! read -r version saved_pid saved_pgid saved_start saved_identity < "$STATE_FILE"; then
            return 0
        fi
        if [[ "$version" != 1 \
            || "$saved_pid" != "$miner_pid" \
            || "$saved_pgid" != "$miner_pgid" \
            || "$saved_start" != "$miner_proc_start" \
            || "$saved_identity" != "$miner_exe_identity" ]]; then
            return 0
        fi
    fi
    _pearlski_remove_all_state
}

_pearlski_published_state_is_owned() {
    local version saved_pid saved_pgid saved_start saved_identity

    [[ -r "$STATE_FILE" ]] || return 1
    read -r version saved_pid saved_pgid saved_start saved_identity < "$STATE_FILE" || return 1
    [[ "$version" == 1 \
        && "$saved_pid" == "$miner_pid" \
        && "$saved_pgid" == "$miner_pgid" \
        && "$saved_start" == "$miner_proc_start" \
        && "$saved_identity" == "$miner_exe_identity" ]]
}

_pearlski_stop_group() {
    local pid=${miner_pid:-}
    local pgid=${miner_pgid:-}
    local i

    [[ "$pid" =~ ^[0-9]+$ ]] || return 0

    if [[ "$pgid" =~ ^[0-9]+$ && "$pgid" == "$pid" ]]; then
        kill -TERM -- "-$pgid" 2>/dev/null || true
        for ((i = 0; i < 50; i++)); do
            _pearlski_group_has_live_members "$pgid" || break
            sleep 0.2
        done
        if _pearlski_group_has_live_members "$pgid"; then
            kill -KILL -- "-$pgid" 2>/dev/null || true
            for ((i = 0; i < 25; i++)); do
                _pearlski_group_has_live_members "$pgid" || break
                sleep 0.2
            done
        fi
        wait "$pid" 2>/dev/null || true
        # Give procfs a short grace period after reaping the leader. This also
        # catches a worker that raced with the first disappearance check.
        for ((i = 0; i < 25; i++)); do
            _pearlski_group_has_live_members "$pgid" || return 0
            sleep 0.02
        done
        return 1
    fi

    # The child may receive a stop signal before setsid has established its group.
    kill -TERM "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    ! kill -0 "$pid" 2>/dev/null
}

_pearlski_capture_output() {
    local line clean tmp

    exec 9>&-
    exec 3>>"$run_log_file" || return 1
    shopt -s nocasematch
    while IFS= read -r line || [[ -n "$line" ]]; do
        printf '%s\n' "$line"
        printf '%s\n' "$line" >&3

        clean=$(sed -E $'s/\\x1B\\[[0-9;]*[[:alpha:]]//g; s/\r$//' <<< "$line")
        [[ "$clean" =~ GPU\[[0-9]+\] ]] || continue
        [[ "$clean" =~ \|[[:space:]]*A:[0-9]+[[:space:]]+R:[0-9]+ ]] || continue
        tmp="$run_stats_file.tmp.$BASHPID"
        if (umask 077; printf '%s\n' "$clean" > "$tmp") && mv -f -- "$tmp" "$run_stats_file"; then
            :
        else
            rm -f -- "$tmp"
        fi
    done
}

_pearlski_cleanup() {
    local owns_process=0 group_stopped=0

    [[ ${cleanup_done:-0} == 0 ]] || return 0
    cleanup_done=1
    trap - EXIT TERM INT

    if (( ! lock_held )); then
        flock -x 9
        lock_held=1
    fi

    exec 8>&- || true
    if (( ! state_published )) || _pearlski_published_state_is_owned; then
        owns_process=1
    fi

    if (( owns_process )) && _pearlski_stop_group; then
        group_stopped=1
        _pearlski_remove_owned_state
    elif (( owns_process )); then
        _pearlski_remove_owned_generation
        echo "Pearlski cleanup error: miner process group $miner_pgid is still alive" >&2
    fi

    [[ -n "${state_tmp:-}" ]] && rm -f -- "$state_tmp"
    [[ -n "${start_tmp:-}" ]] && rm -f -- "$start_tmp"
    [[ -n "${generation_tmp:-}" ]] && rm -f -- "$generation_tmp"
    [[ -n "${log_link_tmp:-}" ]] && rm -f -- "$log_link_tmp"
    flock -u 9 2>/dev/null || true
    lock_held=0

    if (( group_stopped )) && [[ "${capture_pid:-}" =~ ^[0-9]+$ ]]; then
        wait "$capture_pid" 2>/dev/null || true
        capture_pid=
    elif [[ "${capture_pid:-}" =~ ^[0-9]+$ ]]; then
        kill -TERM "$capture_pid" 2>/dev/null || true
        wait "$capture_pid" 2>/dev/null || true
        capture_pid=
    fi

    [[ -n "${run_stats_file:-}" ]] && rm -f -- "$run_stats_file" "$run_stats_file".tmp.*
}

exec 9>"$LOCK_FILE" || {
    echo "Pearlski run error: could not open lifecycle lock: $LOCK_FILE" >&2
    exit 1
}
if ! flock -x 9; then
    echo "Pearlski run error: could not acquire lifecycle lock" >&2
    exit 1
fi
lock_held=1

if _pearlski_saved_state_is_live; then
    echo "Pearlski run error: another miner instance is already running" >&2
    flock -u 9
    exit 1
fi
_pearlski_remove_all_state

wrapper_proc_start=$(awk '{print $22}' "/proc/$$/stat" 2>/dev/null || true)
[[ "$wrapper_proc_start" =~ ^[0-9]+$ ]] || wrapper_proc_start=$(date +%s)
run_token="run-$$-$wrapper_proc_start-$RANDOM-$RANDOM"
run_log_file="${LOG_FILE}.${run_token}"
run_stats_file="${STATS_LINE_FILE}.${run_token}"

# Each run writes to its own inodes. The stable HiveOS log path is atomically
# hard-linked to the current run, so a delayed old capture cannot pollute it.
rm -f -- "$LOG_FILE".run-* "$STATS_LINE_FILE".run-*
if ! (umask 022; : > "$run_log_file") || ! chmod 644 "$run_log_file"; then
    echo "Pearlski run error: could not create generation log: $run_log_file" >&2
    flock -u 9
    exit 1
fi
log_link_tmp="${LOG_FILE}.link.$$.$RANDOM"
rm -f -- "$log_link_tmp"
if ! ln "$run_log_file" "$log_link_tmp" \
    || ! mv -fT -- "$log_link_tmp" "$LOG_FILE"; then
    rm -f -- "$log_link_tmp" "$run_log_file"
    echo "Pearlski run error: could not publish log: $LOG_FILE" >&2
    flock -u 9
    exit 1
fi
log_link_tmp=
if ! (umask 077; : > "$STATS_MODE_FILE") || ! chmod 600 "$STATS_MODE_FILE"; then
    echo "Pearlski run error: could not enable fresh stats snapshots" >&2
    rm -f -- "$run_log_file"
    flock -u 9
    exit 1
fi

trap '_pearlski_cleanup; exit 143' TERM
trap '_pearlski_cleanup; exit 130' INT
trap '_pearlski_cleanup' EXIT

cd "$SCRIPT_DIR" || exit 1
exec 8> >(_pearlski_capture_output)
capture_pid=$!

setsid "$BIN" "${PEARLSKI_ARGS[@]}" 9>&- >&8 2>&1 &
miner_pid=$!
exec 8>&-

bin_identity=$(stat -Lc '%d:%i' "$BIN" 2>/dev/null || true)
established=0
for ((i = 0; i < 100; i++)); do
    miner_pgid=$(ps -o pgid= -p "$miner_pid" 2>/dev/null | tr -d ' ')
    miner_proc_start=$(awk '{print $22}' "/proc/$miner_pid/stat" 2>/dev/null || true)
    miner_exe_identity=$(_pearlski_proc_exe_identity "$miner_pid")
    if [[ "$miner_pgid" =~ ^[0-9]+$ \
        && "$miner_pgid" == "$miner_pid" \
        && "$miner_proc_start" =~ ^[0-9]+$ \
        && "$miner_exe_identity" =~ ^[0-9]+:[0-9]+$ \
        && "$miner_exe_identity" == "$bin_identity" ]]; then
        established=1
        break
    fi
    kill -0 "$miner_pid" 2>/dev/null || break
    sleep 0.02
done
if (( ! established )); then
    echo "Pearlski run error: could not establish an isolated miner process group" >&2
    exit 1
fi

start_epoch=$(date +%s) || exit 1
start_tmp=$(mktemp "$SCRIPT_DIR/.miner-start.XXXXXX") || exit 1
if ! printf '%s\n' "$start_epoch" > "$start_tmp" \
    || ! chmod 600 "$start_tmp" \
    || ! mv -f -- "$start_tmp" "$START_FILE"; then
    echo "Pearlski run error: could not publish miner start time" >&2
    exit 1
fi
start_tmp=

state_tmp=$(mktemp "$SCRIPT_DIR/.miner-state.XXXXXX") || exit 1
if ! printf '1 %s %s %s %s\n' \
        "$miner_pid" "$miner_pgid" "$miner_proc_start" "$miner_exe_identity" > "$state_tmp" \
    || ! chmod 600 "$state_tmp" \
    || ! mv -f -- "$state_tmp" "$STATE_FILE"; then
    echo "Pearlski run error: could not publish miner lifecycle state" >&2
    exit 1
fi
state_tmp=
state_published=1

generation_tmp=$(mktemp "$SCRIPT_DIR/.capture-generation.XXXXXX") || exit 1
if ! printf '%s\n' "$run_token" > "$generation_tmp" \
    || ! chmod 600 "$generation_tmp" \
    || ! mv -f -- "$generation_tmp" "$GENERATION_FILE"; then
    echo "Pearlski run error: could not publish capture generation" >&2
    exit 1
fi
generation_tmp=

flock -u 9
lock_held=0

wait "$miner_pid"
miner_status=$?
_pearlski_cleanup
exit "$miner_status"
