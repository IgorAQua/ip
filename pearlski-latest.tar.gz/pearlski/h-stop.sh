#!/usr/bin/env bash

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
STATE_FILE="$SCRIPT_DIR/miner.state"
LOCK_FILE="$SCRIPT_DIR/miner.lock"
START_FILE="$SCRIPT_DIR/miner_start_time"
STATS_LINE_FILE="$SCRIPT_DIR/miner_latest_stats"
GENERATION_FILE="$SCRIPT_DIR/capture.generation"
BIN=$(readlink -f "$SCRIPT_DIR/pearlski-miner")

# Backward-compatible state from wrapper versions before the atomic state file.
LEGACY_PID_FILE="$SCRIPT_DIR/miner.pid"
LEGACY_PGID_FILE="$SCRIPT_DIR/miner.pgid"
LEGACY_PROC_START_FILE="$SCRIPT_DIR/miner_proc_start"

if ! command -v flock >/dev/null 2>&1; then
    echo "Pearlski stop error: flock is required for serialized lifecycle control" >&2
    exit 1
fi

_pearlski_remove_state() {
    local token

    token=
    if [[ -r "$GENERATION_FILE" ]]; then
        read -r token < "$GENERATION_FILE" || token=
    fi
    rm -f -- \
        "$STATE_FILE" "$START_FILE" "$STATS_LINE_FILE" "$GENERATION_FILE" \
        "$LEGACY_PID_FILE" "$LEGACY_PGID_FILE" "$LEGACY_PROC_START_FILE"
    if [[ "$token" =~ ^run-[0-9]+-[0-9]+-[0-9]+-[0-9]+$ ]]; then
        rm -f -- "$STATS_LINE_FILE.$token" "$STATS_LINE_FILE.$token".tmp.*
    fi
}

_pearlski_invalidate_generation() {
    local token

    token=
    if [[ -r "$GENERATION_FILE" ]]; then
        read -r token < "$GENERATION_FILE" || token=
    fi
    rm -f -- "$GENERATION_FILE"
    if [[ "$token" =~ ^run-[0-9]+-[0-9]+-[0-9]+-[0-9]+$ ]]; then
        rm -f -- "$STATS_LINE_FILE.$token" "$STATS_LINE_FILE.$token".tmp.*
    fi
}

_pearlski_group_has_live_members() {
    ps -eo pgid=,stat= 2>/dev/null \
        | awk -v wanted="$1" '$1 == wanted && $2 !~ /^Z/ { found=1 } END { exit !found }'
}

_pearlski_proc_exe_identity() {
    stat -Lc '%d:%i' "/proc/$1/exe" 2>/dev/null
}

_pearlski_group_has_identity() {
    local wanted_pgid=$1 wanted_identity=$2
    local member member_pgid member_stat identity

    while read -r member member_pgid member_stat; do
        [[ "$member_pgid" == "$wanted_pgid" && "$member_stat" != Z* ]] || continue
        identity=$(_pearlski_proc_exe_identity "$member")
        [[ "$identity" == "$wanted_identity" ]] && return 0
    done < <(ps -eo pid=,pgid=,stat= 2>/dev/null)
    return 1
}

_pearlski_group_has_legacy_binary() {
    local wanted_pgid=$1
    local member member_pgid member_stat exe

    while read -r member member_pgid member_stat; do
        [[ "$member_pgid" == "$wanted_pgid" && "$member_stat" != Z* ]] || continue
        exe=$(readlink -f "/proc/$member/exe" 2>/dev/null || true)
        exe=${exe%" (deleted)"}
        [[ "$exe" == "$BIN" ]] && return 0
    done < <(ps -eo pid=,pgid=,stat= 2>/dev/null)
    return 1
}

exec 9>"$LOCK_FILE" || {
    echo "Pearlski stop error: could not open lifecycle lock: $LOCK_FILE" >&2
    exit 1
}
if ! flock -x 9; then
    echo "Pearlski stop error: could not acquire lifecycle lock" >&2
    exit 1
fi

state_version=legacy
pid=
pgid=
saved_start=
saved_identity=
if [[ -r "$STATE_FILE" ]]; then
    if ! read -r state_version pid pgid saved_start saved_identity < "$STATE_FILE" \
        || [[ "$state_version" != 1 ]]; then
        _pearlski_remove_state
        exit 0
    fi
elif [[ -r "$LEGACY_PID_FILE" ]]; then
    read -r pid < "$LEGACY_PID_FILE" || pid=
    read -r pgid < "$LEGACY_PGID_FILE" 2>/dev/null || pgid=
    read -r saved_start < "$LEGACY_PROC_START_FILE" 2>/dev/null || saved_start=
else
    _pearlski_remove_state
    exit 0
fi

if [[ ! "$pid" =~ ^[0-9]+$ \
    || ! "$pgid" =~ ^[0-9]+$ \
    || "$pgid" != "$pid" \
    || ! "$saved_start" =~ ^[0-9]+$ ]]; then
    _pearlski_remove_state
    exit 0
fi
if [[ "$state_version" == 1 && ! "$saved_identity" =~ ^[0-9]+:[0-9]+$ ]]; then
    _pearlski_remove_state
    exit 0
fi

valid_group=0
current_start=$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null || true)
if [[ "$current_start" == "$saved_start" ]]; then
    # PID plus Linux process-start token remains stable across an on-disk replacement.
    valid_group=1
elif [[ "$state_version" == 1 ]] && _pearlski_group_has_identity "$pgid" "$saved_identity"; then
    valid_group=1
elif [[ "$state_version" == legacy ]] && _pearlski_group_has_legacy_binary "$pgid"; then
    valid_group=1
fi

if [[ "$valid_group" != 1 ]]; then
    _pearlski_remove_state
    exit 0
fi

# Make stats unavailable before terminating the group. Any delayed capture can
# only write its private generation file, never a future run's snapshot.
_pearlski_invalidate_generation

kill -TERM -- "-$pgid" 2>/dev/null || true
for ((i = 0; i < 50; i++)); do
    _pearlski_group_has_live_members "$pgid" || break
    sleep 0.2
done
if _pearlski_group_has_live_members "$pgid"; then
    kill -KILL -- "-$pgid" 2>/dev/null || true
    for ((i = 0; i < 25; i++)); do
        _pearlski_group_has_live_members "$pgid" || break
        sleep 0.2
    done
fi

if _pearlski_group_has_live_members "$pgid"; then
    echo "Pearlski stop error: miner process group $pgid is still alive" >&2
    exit 1
fi

_pearlski_remove_state
