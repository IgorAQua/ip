#!/usr/bin/env bash

# HiveOS custom-miner configuration for Pearlski.

_pearlski_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$_pearlski_dir/h-manifest.conf"

_pearlski_download_update_stdout() {
    local url="$1"
    local connect_timeout=${PEARLSKI_UPDATE_CONNECT_TIMEOUT_SEC:-10}
    local max_time=${PEARLSKI_UPDATE_MAX_TIME_SEC:-30}

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL \
            --connect-timeout "$connect_timeout" \
            --max-time "$max_time" \
            --retry 2 \
            "$url" 2>/dev/null
    elif command -v wget >/dev/null 2>&1; then
        wget -q \
            --connect-timeout="$connect_timeout" \
            --timeout="$max_time" \
            --tries=3 \
            -O - "$url" 2>/dev/null
    else
        return 1
    fi
}

_pearlski_normalize_update_hash() {
    awk 'NF {print $1; exit}' | tr -d '\r' | tr '[:upper:]' '[:lower:]'
}

_pearlski_schedule_hive_restart() {
    [[ "${PEARLSKI_UPDATE_RESTART:-1}" == "0" ]] && return 0

    if command -v screen >/dev/null 2>&1 && command -v miner >/dev/null 2>&1; then
        screen -d -m miner restart
    elif command -v miner >/dev/null 2>&1; then
        (sleep 1; miner restart) >/dev/null 2>&1 &
    else
        echo "Auto-update: miner restart command not available"
    fi
}

_pearlski_check_auto_update() {
    local remote_hash local_hash local_file install_archive

    [[ "${PEARLSKI_AUTO_UPDATE:-1}" == "0" ]] && return 0

    if [[ -n "${CUSTOM_INSTALL_URL:-}" ]]; then
        install_archive=${CUSTOM_INSTALL_URL%%\?*}
        install_archive=${install_archive##*/}
        if [[ "$install_archive" != "$PEARLSKI_UPDATE_ARCHIVE" ]]; then
            echo "Auto-update skipped: Flight Sheet archive '$install_archive' does not match '$PEARLSKI_UPDATE_ARCHIVE'"
            return 0
        fi
    fi

    remote_hash=$(_pearlski_download_update_stdout "$PEARLSKI_UPDATE_HASH_URL" | _pearlski_normalize_update_hash)
    if [[ ! "$remote_hash" =~ ^[0-9a-f]{64}$ ]]; then
        echo "Auto-update skipped: no valid hash at $PEARLSKI_UPDATE_HASH_URL"
        return 0
    fi

    local_file="${PEARLSKI_UPDATE_LOCAL_FILE:-/hive/miners/custom/downloads/$PEARLSKI_UPDATE_ARCHIVE}"
    if [[ ! -f "$local_file" ]]; then
        echo "Auto-update skipped: local HiveOS archive cache not found: $local_file"
        return 0
    fi

    if ! command -v sha256sum >/dev/null 2>&1; then
        echo "Auto-update skipped: sha256sum is not available"
        return 0
    fi
    local_hash=$(sha256sum "$local_file" 2>/dev/null | awk '{print $1}' | tr '[:upper:]' '[:lower:]')
    if [[ ! "$local_hash" =~ ^[0-9a-f]{64}$ ]]; then
        echo "Auto-update skipped: could not hash local archive: $local_file"
        return 0
    fi
    if [[ "$local_hash" == "$remote_hash" ]]; then
        return 0
    fi

    echo "Auto-update: cached archive differs from remote, clearing $local_file"
    if ! rm -f -- "$local_file"; then
        echo "Auto-update skipped: could not remove cached archive: $local_file"
        return 0
    fi
    echo "Auto-update: requesting HiveOS miner restart"
    _pearlski_schedule_hive_restart
}

_pearlski_fail() {
    echo "Pearlski config error: $*" >&2
    return 1
}

_pearlski_pool_from_url() {
    local raw="$1" endpoint port had_nocasematch=0

    # The binary accepts one bare HOST:PORT endpoint. Hive may supply a list.
    raw=${raw//$'\r'/ }
    raw=${raw//$'\n'/ }
    raw=${raw#"${raw%%[![:space:]]*}"}
    raw=${raw%%[[:space:],;]*}
    [[ -n "$raw" ]] || _pearlski_fail "CUSTOM_URL must contain a pool endpoint" || return 1

    PEARLSKI_CONFIG_TLS=0
    shopt -q nocasematch && had_nocasematch=1
    shopt -s nocasematch
    case "$raw" in
        stratum+tcp://*) endpoint=${raw#*://} ;;
        stratum://*) endpoint=${raw#*://} ;;
        tcp://*) endpoint=${raw#*://} ;;
        stratum+ssl://*|stratum+tls://*|ssl://*|tls://*)
            endpoint=${raw#*://}
            PEARLSKI_CONFIG_TLS=1
            ;;
        *://*)
            (( had_nocasematch )) || shopt -u nocasematch
            _pearlski_fail "unsupported pool URL scheme in CUSTOM_URL" || return 1
            ;;
        *) endpoint=$raw ;;
    esac
    (( had_nocasematch )) || shopt -u nocasematch

    endpoint=${endpoint%/}
    case "${endpoint,,}" in
        jetskipool.ai|www.jetskipool.ai|pearl.jetskipool.ai|pearlski.jetskipool.ai)
            endpoint=${PEARLSKI_DEFAULT_POOL_ENDPOINT:-pearlski.jetskipool.ai:6970}
            ;;
    esac
    if [[ "$endpoint" =~ ^\[[^][]+\]:([0-9]{1,5})$ ]]; then
        port=${BASH_REMATCH[1]}
    elif [[ "$endpoint" =~ ^[^:/[:space:]]+:([0-9]{1,5})$ ]]; then
        port=${BASH_REMATCH[1]}
    else
        _pearlski_fail "pool must resolve to HOST:PORT (IPv6 must use [ADDR]:PORT)" || return 1
    fi

    if (( 10#$port < 1 || 10#$port > 65535 )); then
        _pearlski_fail "pool port must be between 1 and 65535" || return 1
    fi

    PEARLSKI_CONFIG_POOL=$endpoint
}

_pearlski_gpu_selection() {
    local -a words=()
    local value=auto user_config=${CUSTOM_USER_CONFIG:-}

    user_config=${user_config//$'\r'/ }
    user_config=${user_config//$'\n'/ }
    user_config=${user_config#"${user_config%%[![:space:]]*}"}
    user_config=${user_config%"${user_config##*[![:space:]]}"}
    if [[ -n "$user_config" ]]; then
        read -r -a words <<< "$user_config"
        case ${#words[@]} in
            1)
                if [[ "${words[0]}" == --gpus=* ]]; then
                    value=${words[0]#--gpus=}
                else
                    _pearlski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                fi
                ;;
            2)
                if [[ "${words[0]}" == "--gpus" ]]; then
                    value=${words[1]}
                else
                    _pearlski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                fi
                ;;
            *)
                _pearlski_fail "extra config supports only --gpus auto|all|0,1" || return 1
                ;;
        esac
    fi

    if [[ "$value" != auto && "$value" != all && ! "$value" =~ ^[0-9]+(,[0-9]+)*$ ]]; then
        _pearlski_fail "invalid --gpus value: $value" || return 1
    fi
    PEARLSKI_CONFIG_GPUS=$value
}

_pearlski_write_config() {
    local template wallet worker config_file config_dir tmp
    local -a args

    template=${CUSTOM_TEMPLATE:-}
    template=${template#"${template%%[![:space:]]*}"}
    template=${template%%[[:space:]]*}
    [[ -n "$template" ]] || _pearlski_fail "CUSTOM_TEMPLATE must contain a wallet" || return 1

    wallet=${template%%.*}
    if [[ "$template" == *.* ]]; then
        worker=${template#*.}
    else
        worker=${WORKER_NAME:-$(hostname -s)}
    fi
    [[ -n "$wallet" ]] || _pearlski_fail "wallet is empty" || return 1
    [[ -n "$worker" ]] || worker=$(hostname -s)

    _pearlski_pool_from_url "${CUSTOM_URL:-}" || return 1
    _pearlski_gpu_selection || return 1

    args=(--user "$wallet" --worker "$worker" --pool "$PEARLSKI_CONFIG_POOL" --gpus "$PEARLSKI_CONFIG_GPUS")
    config_file=${CUSTOM_CONFIG_FILENAME:-$_pearlski_dir/pearlski.conf}
    config_dir=$(dirname -- "$config_file")
    mkdir -p "$config_dir" || return 1
    tmp="$config_file.tmp.$$"

    {
        printf 'PEARLSKI_ARGS=('
        printf ' %q' "${args[@]}"
        printf ' )\n'
        printf 'PEARLSKI_USE_TLS=%q\n' "$PEARLSKI_CONFIG_TLS"
    } > "$tmp" || {
        rm -f "$tmp"
        return 1
    }
    if ! chmod 600 "$tmp"; then
        rm -f -- "$tmp"
        _pearlski_fail "could not secure temporary config: $tmp" || return 1
    fi
    if ! mv -f -- "$tmp" "$config_file"; then
        rm -f -- "$tmp"
        _pearlski_fail "could not install config: $config_file" || return 1
    fi

    echo "Pearlski configured for worker '$worker', pool '$PEARLSKI_CONFIG_POOL', GPUs '$PEARLSKI_CONFIG_GPUS'"
}

_pearlski_check_auto_update
_pearlski_write_config
_pearlski_status=$?

unset -f _pearlski_download_update_stdout _pearlski_normalize_update_hash
unset -f _pearlski_schedule_hive_restart _pearlski_check_auto_update
unset -f _pearlski_fail _pearlski_pool_from_url _pearlski_gpu_selection _pearlski_write_config
unset _pearlski_dir
return "$_pearlski_status" 2>/dev/null || exit "$_pearlski_status"
